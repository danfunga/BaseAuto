# BaseAuto

## Target
*  Memu AppPlayer
   * 640 X 400 : 133 dpi
   * 480 X 300 : 100 dpi
